from sqlalchemy import select

from models import Livro


def emprestar_livro(session, titulo):
    """Marque um livro como indisponível."""
    livro = session.execute(
        select(Livro).where(Livro.titulo.ilike(titulo))
    ).scalars().first()

    if livro is None:
        print(f"Livro '{titulo}' não encontrado.")
        return

    if not livro.disponivel:
        print(f"Livro '{livro.titulo}' já está indisponível.")
        return

    livro.disponivel = False
    session.commit()
    print(f"Livro '{livro.titulo}' emprestado com sucesso.")


def devolver_livro(session, titulo):
    """Marque um livro como disponível."""
    livro = session.execute(
        select(Livro).where(Livro.titulo.ilike(titulo))
    ).scalars().first()

    if livro is None:
        print(f"Livro '{titulo}' não encontrado.")
        return

    if livro.disponivel:
        print(f"Livro '{livro.titulo}' já está disponível.")
        return

    livro.disponivel = True
    session.commit()
    print(f"Livro '{livro.titulo}' devolvido com sucesso.")
