from sqlalchemy import select

from models import Autor, Livro


def listar_livros(session):
    """Liste todos os livros com o nome do autor e o status de disponibilidade."""
    livros = session.execute(select(Livro)).scalars().all()

    if not livros:
        print("Nenhum livro cadastrado.")
        return

    for livro in livros:
        autor_nome = livro.autor.nome if livro.autor else "Autor desconhecido"
        status = "Disponível" if livro.disponivel else "Indisponível"
        print(f"- {livro.titulo} | Autor: {autor_nome} | Status: {status}")


def listar_livros_disponiveis(session):
    """Liste apenas os livros disponíveis."""
    livros = session.execute(
        select(Livro).where(Livro.disponivel.is_(True)).order_by(Livro.titulo)
    ).scalars().all()

    if not livros:
        print("Nenhum livro disponível.")
        return

    for livro in livros:
        autor_nome = livro.autor.nome if livro.autor else "Autor desconhecido"
        print(f"- {livro.titulo} | Autor: {autor_nome}")


def buscar_livros_por_titulo(session, trecho):
    """Busque livros por parte do título."""
    livros = session.execute(select(Livro)).scalars().all()
    encontrados = [
        livro for livro in livros if trecho.lower() in livro.titulo.lower()
    ]

    if not encontrados:
        print(f"Nenhum livro encontrado com o trecho: '{trecho}'")
        return

    for livro in encontrados:
        autor_nome = livro.autor.nome if livro.autor else "Autor desconhecido"
        print(f"- {livro.titulo} | Autor: {autor_nome}")


def listar_livros_por_autor(session, nome_autor):
    """Liste os livros de um autor informado pelo nome."""
    autores = session.execute(select(Autor)).scalars().all()
    autor = None

    for item in autores:
        if nome_autor.lower() in item.nome.lower():
            autor = item
            break

    if autor is None:
        print(f"Nenhum autor encontrado com o nome: '{nome_autor}'")
        return

    if not autor.livros:
        print(f"O autor '{autor.nome}' não possui livros cadastrados.")
        return

    print(f"Livros do autor {autor.nome}:")
    for livro in autor.livros:
        status = "Disponível" if livro.disponivel else "Indisponível"
        print(f"- {livro.titulo} | Status: {status}")
