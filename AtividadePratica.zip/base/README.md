# Atividade Prática 02 - Biblioteca Persistente

Consulta ORM validada com marcador AP02-SQLA-2026

Complete os arquivos da base usando SQLAlchemy ORM.

## Como executar

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python main.py
```

## Defesa escrita

Responda ao final:

1. Para que serve o campo `disponivel` em `Livro`?
O  campo de disponível serve pra dzer se o ivro está ou não disponível, usando o True pra dizer que PODE ser emprestado e o False como indisponível ou que já foi emprestado/reservado, ai ele é usado pelo emprestar_livro() paramudar de True pra False e devolver_livro para mudar de false para True


2. Por que é necessário chamar `session.commit()` após emprestar ou devolver?

Pra o session.commit salvar a alteração no banco PERMANENTEMENTE.

ele faz no emprestar_livro() e devolver_livro(), as mudanças ficam primeiro na session do alchemy, ent se nn dar o commit(), o banco nn vai salvar nada e o status do livro continua igual antes na base de dados


3. Em qual consulta você usa o relacionamento entre `Livro` e `Autor`?

O campo disponivel em Livro serve para indicar se o livro está disponível para empréstimo, True significa que ele PODE ser emprestado e False que ele está INDISPONÍVEL, o session.commit() é necessário porque ele salva a mudança no banco de dados de forma permanente, sem ele, a alteração fica só na sessão e não é gravada. O relacionamento entre Livro e Autor é usado principalmente na consulta que lista todos os livros com o nome do autor, acessando livro.autor.nome, e também na busca por livros de um autor, navegando por autor.livros.