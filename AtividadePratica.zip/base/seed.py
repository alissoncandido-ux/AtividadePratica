from sqlalchemy import select

from models import Autor, Livro


def popular_banco(session):
    """Cadastre autores e livros iniciais para testar a aplicação."""
    autores_existentes = session.execute(select(Autor)).scalars().all()
    if autores_existentes:
        return

    autor1 = Autor(nome="Manoelzinho Fofuxo", pais="Brasil")
    autor2 = Autor(nome="Luci Lindinha", pais="Bahia")
    autor3 = Autor(nome="J. K. Rowling", pais="Reino Unido")

    session.add(autor1)
    session.add_all([autor2, autor3])
    session.commit()

    livros = [
        Livro(titulo="Dom Casmurro", ano=1899, autor=autor1, disponivel=True),
        Livro(titulo="Memórias Póstumas de Brás Cubas", ano=1881, autor=autor1, disponivel=False),
        Livro(titulo="1984", ano=1949, autor=autor2, disponivel=True),
        Livro(titulo="A Revolução dos Bichos", ano=1945, autor=autor2, disponivel=False),
        Livro(titulo="Harry Potter e a Pedra Filosofal", ano=1997, autor=autor3, disponivel=True),
        Livro(titulo="Harry Potter e a Câmara Secreta", ano=1998, autor=autor3, disponivel=True),
    ]

    session.add_all(livros)
    session.commit()
